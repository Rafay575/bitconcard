import TimeAgo from 'javascript-time-ago';

import en from 'javascript-time-ago/locale/en';

TimeAgo.addDefaultLocale(en);


export function maskCreditCard(cardNumber) {
  // Remove spaces and non-digit characters from the input
  const cleanedNumber = cardNumber.replace(/\D/g, "");

  // Check if the cleaned input has at least 4 digits
  if (cleanedNumber.length >= 4) {
    // Mask all but the last 4 digits
    const maskedNumber =cleanedNumber.slice(0,4)+ " **** **** " + cleanedNumber.slice(-4);
    return maskedNumber;
  } else {
    return "Error, please contact support.";
  }
}

export function countdownTo(createdAt) {
  // Parse the target date string into a Date object
  const timeAgo = new TimeAgo("en-US");
  const targetDate = new Date(createdAt);
  // get formatted date
  return timeAgo.format(targetDate);
}

export function formatDate(inputDate) {
  const options = {
    month: "long",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  };
  return new Date(inputDate).toLocaleDateString(undefined, options);
}

export function formatCurrency(amount) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(amount);
}

export const splitedBalance = (balance) => {
  const splited = balance.split(".");
  return {
    integer: splited[0],
    decimal: splited[1],
  };
};

export function calculatePercentage({ number, percentage }) {
  // Check if the inputs are valid numbers
  if (typeof number !== "number" || typeof percentage !== "number") {
    return "Invalid input";
  }

  // Calculate the percentage
  const result = (percentage / 100) * number;

  return result.toFixed(2);
}

export const formatMoney = (amount) => {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(amount);
};

export const formatVisaCardNumber = (cardNumber) =>
  cardNumber.replace(/(.{4})/g, "$1 ");
