(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Admin_layout_f0f0eb.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Admin_layout_f0f0eb.js",
  "chunks": [
    "static/chunks/_f4b013._.js"
  ],
  "source": "dynamic"
});
