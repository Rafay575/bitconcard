(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Admin_dashboard_page_59cd4d.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Admin_dashboard_page_59cd4d.js",
  "chunks": [
    "static/chunks/_0d3b56._.js"
  ],
  "source": "dynamic"
});
