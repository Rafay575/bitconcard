(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_61af54.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_61af54.js",
  "chunks": [
    "static/chunks/node_modules_221c4f._.js",
    "static/chunks/_c52130._.js",
    "static/chunks/_d54501._.css"
  ],
  "source": "dynamic"
});
