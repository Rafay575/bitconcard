(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Admin_transactions_page_4f1f10.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Admin_transactions_page_4f1f10.js",
  "chunks": [
    "static/chunks/node_modules_9b4101._.js",
    "static/chunks/_f63669._.js"
  ],
  "source": "dynamic"
});
