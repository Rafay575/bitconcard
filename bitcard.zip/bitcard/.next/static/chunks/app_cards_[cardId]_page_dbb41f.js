(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_cards_[cardId]_page_dbb41f.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_cards_[cardId]_page_dbb41f.js",
  "chunks": [
    "static/chunks/node_modules__pnpm_375856._.js",
    "static/chunks/_fa6a98._.js"
  ],
  "source": "dynamic"
});
