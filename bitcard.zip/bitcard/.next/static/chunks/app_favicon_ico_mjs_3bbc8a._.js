(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_favicon_ico_mjs_3bbc8a._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_favicon_ico_mjs_3bbc8a._.js",
  "chunks": [
    "static/chunks/_69423d._.js"
  ],
  "source": "dynamic"
});
