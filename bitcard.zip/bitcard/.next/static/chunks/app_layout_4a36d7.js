(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_4a36d7.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_4a36d7.js",
  "chunks": [
    "static/chunks/node_modules__pnpm_d3ae31._.js",
    "static/chunks/_c52130._.js",
    "static/chunks/_29e134._.css"
  ],
  "source": "dynamic"
});
