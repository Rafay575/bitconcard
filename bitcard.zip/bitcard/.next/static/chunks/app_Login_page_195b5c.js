(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Login_page_195b5c.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Login_page_195b5c.js",
  "chunks": [
    "static/chunks/_a1885e._.js",
    "static/chunks/node_modules__pnpm_42147b._.js"
  ],
  "source": "dynamic"
});
