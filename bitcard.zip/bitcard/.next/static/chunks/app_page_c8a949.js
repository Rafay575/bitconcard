(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_c8a949.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_c8a949.js",
  "chunks": [
    "static/chunks/_f3d22a._.js"
  ],
  "source": "dynamic"
});
