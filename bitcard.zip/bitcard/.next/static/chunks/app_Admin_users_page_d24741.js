(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Admin_users_page_d24741.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Admin_users_page_d24741.js",
  "chunks": [
    "static/chunks/node_modules__pnpm_ede658._.js",
    "static/chunks/_5986e4._.js"
  ],
  "source": "dynamic"
});
