(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Admin_dashboard_page_9ec822.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Admin_dashboard_page_9ec822.js",
  "chunks": [
    "static/chunks/_f25c19._.js"
  ],
  "source": "dynamic"
});
