(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Admin_dashboard_page_d24741.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Admin_dashboard_page_d24741.js",
  "chunks": [
    "static/chunks/node_modules__pnpm_d6422e._.js",
    "static/chunks/_28dafa._.js"
  ],
  "source": "dynamic"
});
