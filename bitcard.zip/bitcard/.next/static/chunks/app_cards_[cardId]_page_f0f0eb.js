(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_cards_[cardId]_page_f0f0eb.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_cards_[cardId]_page_f0f0eb.js",
  "chunks": [
    "static/chunks/node_modules_ed1926._.js",
    "static/chunks/_fa6a98._.js"
  ],
  "source": "dynamic"
});
