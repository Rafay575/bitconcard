(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_462fd4.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_462fd4.js",
  "chunks": [
    "static/chunks/node_modules_next_dist_016204._.js",
    "static/chunks/_8ecd22._.js"
  ],
  "source": "dynamic"
});
