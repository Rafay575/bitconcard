(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Login_page_38c64c.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Login_page_38c64c.js",
  "chunks": [
    "static/chunks/node_modules_c212df._.js",
    "static/chunks/_a1885e._.js"
  ],
  "source": "dynamic"
});
