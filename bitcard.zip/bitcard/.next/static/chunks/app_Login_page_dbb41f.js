(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Login_page_dbb41f.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Login_page_dbb41f.js",
  "chunks": [
    "static/chunks/_8304de._.js",
    "static/chunks/node_modules__pnpm_42147b._.js"
  ],
  "source": "dynamic"
});
