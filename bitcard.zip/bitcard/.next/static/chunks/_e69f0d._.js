(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/_e69f0d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/_e69f0d._.js",
  "chunks": [
    "static/chunks/7d341_next_dist_compiled_react-dom_78bccc._.js",
    "static/chunks/7d341_next_dist_compiled_3d6fe6._.js",
    "static/chunks/7d341_next_dist_client_ea142b._.js",
    "static/chunks/7d341_next_dist_a94315._.js",
    "static/chunks/61dca_@swc_helpers_cjs_e27e0a._.js",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1e477d._.js"
  ],
  "source": "entry"
});
