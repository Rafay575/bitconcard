(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/pages__app_5771e1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/pages__app_5771e1._.js",
  "chunks": [
    "static/chunks/[root of the server]__0f1454._.js",
    "static/chunks/545c3_react-dom_1c85ba._.js",
    "static/chunks/node_modules__pnpm_f84813._.js",
    "static/chunks/[root of the server]__f265a1._.js"
  ],
  "source": "entry"
});
