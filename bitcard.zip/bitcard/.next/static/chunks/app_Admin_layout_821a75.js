(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Admin_layout_821a75.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Admin_layout_821a75.js",
  "chunks": [
    "static/chunks/_ef25a7._.js"
  ],
  "source": "dynamic"
});
