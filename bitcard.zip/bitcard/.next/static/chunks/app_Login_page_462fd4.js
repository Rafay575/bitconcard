(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Login_page_462fd4.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Login_page_462fd4.js",
  "chunks": [
    "static/chunks/node_modules_b9fe7b._.js",
    "static/chunks/_a1885e._.js"
  ],
  "source": "dynamic"
});
