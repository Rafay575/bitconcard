(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Login_page_f0f0eb.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Login_page_f0f0eb.js",
  "chunks": [
    "static/chunks/node_modules_4c8119._.js",
    "static/chunks/_8304de._.js"
  ],
  "source": "dynamic"
});
