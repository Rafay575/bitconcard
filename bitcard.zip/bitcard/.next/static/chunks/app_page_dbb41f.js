(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_dbb41f.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_dbb41f.js",
  "chunks": [
    "static/chunks/_e19927._.js",
    "static/chunks/node_modules__pnpm_1c069f._.js"
  ],
  "source": "dynamic"
});
