(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_821a75.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_821a75.js",
  "chunks": [
    "static/chunks/_a3e3cf._.js"
  ],
  "source": "dynamic"
});
