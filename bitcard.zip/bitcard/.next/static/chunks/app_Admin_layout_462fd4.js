(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Admin_layout_462fd4.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Admin_layout_462fd4.js",
  "chunks": [
    "static/chunks/_af797b._.js"
  ],
  "source": "dynamic"
});
