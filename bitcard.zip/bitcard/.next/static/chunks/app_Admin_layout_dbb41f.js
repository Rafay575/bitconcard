(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Admin_layout_dbb41f.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Admin_layout_dbb41f.js",
  "chunks": [
    "static/chunks/_ef25a7._.js"
  ],
  "source": "dynamic"
});
