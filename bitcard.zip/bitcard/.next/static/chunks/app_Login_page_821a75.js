(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Login_page_821a75.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Login_page_821a75.js",
  "chunks": [
    "static/chunks/_a1885e._.js",
    "static/chunks/node_modules__pnpm_3d5303._.js"
  ],
  "source": "dynamic"
});
