(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Admin_layout_c8a949.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Admin_layout_c8a949.js",
  "chunks": [
    "static/chunks/_2b5858._.js"
  ],
  "source": "dynamic"
});
