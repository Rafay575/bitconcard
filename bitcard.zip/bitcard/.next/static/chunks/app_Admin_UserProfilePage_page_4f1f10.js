(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Admin_UserProfilePage_page_4f1f10.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Admin_UserProfilePage_page_4f1f10.js",
  "chunks": [
    "static/chunks/app_Admin_UserProfilePage_page_7e3e03.js"
  ],
  "source": "dynamic"
});
