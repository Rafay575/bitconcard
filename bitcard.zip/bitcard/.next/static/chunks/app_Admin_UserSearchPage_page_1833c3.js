(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Admin_UserSearchPage_page_1833c3.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Admin_UserSearchPage_page_1833c3.js",
  "chunks": [
    "static/chunks/node_modules_242345._.js",
    "static/chunks/_8457f7._.js"
  ],
  "source": "dynamic"
});
