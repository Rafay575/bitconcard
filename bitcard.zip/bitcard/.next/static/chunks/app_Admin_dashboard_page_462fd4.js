(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Admin_dashboard_page_462fd4.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Admin_dashboard_page_462fd4.js",
  "chunks": [
    "static/chunks/_3a3e75._.js"
  ],
  "source": "dynamic"
});
