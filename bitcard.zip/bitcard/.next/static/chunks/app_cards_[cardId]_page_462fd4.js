(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_cards_[cardId]_page_462fd4.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_cards_[cardId]_page_462fd4.js",
  "chunks": [
    "static/chunks/node_modules_5b21cc._.js",
    "static/chunks/_fa6a98._.js"
  ],
  "source": "dynamic"
});
