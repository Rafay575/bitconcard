(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_Admin_dashboard_page_4f1f10.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_Admin_dashboard_page_4f1f10.js",
  "chunks": [
    "static/chunks/node_modules_fa0cf3._.js",
    "static/chunks/_28dafa._.js"
  ],
  "source": "dynamic"
});
