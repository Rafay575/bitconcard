"use client"
import DashboardPage from "@/components/DashboardPage";
import Navbar from "@/components/Navbar";
import ProtectedRoute from "@/components/ProtectedRoute";

export default function Home() {
  return (
    <ProtectedRoute requiredRole="user">
      <div>
        <Navbar />
        <DashboardPage />
      </div>
    </ProtectedRoute>
  )
}
