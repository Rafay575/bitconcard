"use client";
import { useState } from "react";
import Link from "next/link";

import RouteChangePreloader from "@/components/RouteChangePreloader";

export default function AdminLayout({ children }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="h-screen flex overflow-hidden">
      {/* -- DESKTOP SIDEBAR -- */}
      <aside className="hidden md:flex md:flex-col w-64 bg-white border-r shrink-0">
        <div className="px-6 py-4 border-b">
          <h2 className="text-xl font-bold">Admin Dashboard</h2>
        </div>
        <nav className="px-6 py-4 flex-1 overflow-y-auto">
          <ul className="space-y-2">
            <li>
              <Link href="/Admin/dashboard" className="block px-3 py-2 rounded hover:bg-gray-100">
                Dashboard
              </Link>
            </li>
            <li>
              <Link href="/Admin/users" className="block px-3 py-2 rounded hover:bg-gray-100">
                Users
              </Link>
            </li>
            <li>
              <Link href="/Admin/transactions" className="block px-3 py-2 rounded hover:bg-gray-100">
                Transactions
              </Link>
            </li>
            <li>
              <a href="#" className="block px-3 py-2 rounded hover:bg-gray-100">
                Reports
              </a>
            </li>
            <li>
              <a href="#" className="block px-3 py-2 rounded hover:bg-gray-100">
                Settings
              </a>
            </li>
          </ul>
        </nav>
      </aside>

      {/* -- MOBILE SIDEBAR OVERLAY -- */}
      {/* This dark overlay appears when sidebar is open on mobile */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black bg-opacity-25 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* -- MOBILE SIDEBAR SLIDE-IN -- */}
      <aside
        className={`fixed inset-y-0 left-0 bg-white w-64 transform z-50 border-r
                    md:hidden transition-transform duration-200 ease-in-out
                    ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}`}
      >
        <div className="px-6 py-4 border-b flex items-center justify-between">
          <h2 className="text-xl font-bold">Admin Dashboard</h2>
          <button
            className="text-gray-600 focus:outline-none md:hidden"
            onClick={() => setSidebarOpen(false)}
          >
            <svg
              className="w-6 h-6"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </button>
        </div>
        <nav className="px-6 py-4 overflow-y-auto">
          <ul className="space-y-2">
            <li>
              <Link
                href="/admin"
                className="block px-3 py-2 rounded hover:bg-gray-100"
                onClick={() => setSidebarOpen(false)}
              >
                Dashboard
              </Link>
            </li>
            <li>
              <Link
                href="/admin/users"
                className="block px-3 py-2 rounded hover:bg-gray-100"
                onClick={() => setSidebarOpen(false)}
              >
                Users
              </Link>
            </li>
            <li>
              <Link
                href="/admin/transactions"
                className="block px-3 py-2 rounded hover:bg-gray-100"
                onClick={() => setSidebarOpen(false)}
              >
                Transactions
              </Link>
            </li>
            <li>
              <a href="#" className="block px-3 py-2 rounded hover:bg-gray-100">
                Reports
              </a>
            </li>
            <li>
              <a href="#" className="block px-3 py-2 rounded hover:bg-gray-100">
                Settings
              </a>
            </li>
          </ul>
        </nav>
      </aside>

      {/* -- MAIN CONTENT AREA -- */}
      <div className="flex-1 flex flex-col bg-gray-100">
        {/* Top Bar */}
        <div className="fixed md:relative w-full md:w-auto h-16 bg-white border-b flex items-center px-4 z-30">
          {/* Mobile hamburger */}
          <button
            className="text-gray-600 focus:outline-none mr-4 md:hidden"
            onClick={() => setSidebarOpen(!sidebarOpen)}
          >
            {sidebarOpen ? (
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            ) : (
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 6h16M4 12h16M4 18h16"
                />
              </svg>
            )}
          </button>
          <h1 className="text-lg font-bold">Biton Card Admin</h1>
          {/* Add any top bar actions, search, or user profile menu on the right */}
          <div className="ml-auto hidden md:block">
            {/* Example: a search box */}
            <input
              type="text"
              placeholder="Search..."
              className="border border-gray-300 rounded-md px-3 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* The children pages go below the top bar */}
        <main className=" flex-1 overflow-auto p-4">
          {children}
        </main>
      </div>
    </div>
  );
}
