"use client";

import React, { useState } from "react";
const cardData = [
  {
    number: "**** **** 1234",
    balance: 1250.0,
    status: "Active",
  },
  {
    number: "**** **** 5678",
    balance: 500.0,
    status: "Blocked",
  },
];
export default function UserProfilePage() {
  const balance = 1000.0;

  const userStats = [
    { label: "Cards Created", value: "5" },
    { label: "Total Deposited", value: "$10,000" },
    { label: "Earned from Card Creation", value: "$150" },
    { label: "Total Revenue Generated", value: "$575" },
  ];

  const referralStats = [
    { label: "Total Referrals", value: "12" },
    { label: "Active Referred Users", value: "8" },
    { label: "Referral Earnings", value: "$240" },
    { label: "Conversion Rate", value: "20%" },
  ];

  const user = {
    id: 123,
    name: "John Doe",
    email: "john.doe@example.com",
    phone: "+1 555-0100-4567",
    kyc: "ID: #565465465-5454-4xx-xxxx-445654xxxx", // example KYC doc
    verified: true, // if user’s email is verified
    balance: 1800.0,
    stats: {
      savedCards: 5,
      bankAccounts: 2,
      totalSpent: 425,
      totalCreated: 150,
    },
    referral: {
      totalEarned: 240,
      totalReferrals: 10,
      conversionRate: "20%",
    },
    twoFactorAuth: false, // example toggle
  };

  // Example logs
  const logs = [
    {
      date: "2023-06-25 19:35:29",
      action: "Login",
      details: "User logged into the account",
    },
    {
      date: "2023-06-25 18:00:10",
      action: "Card Used",
      details: "Virtual Card used for order #1234",
    },
    {
      date: "2023-06-25 17:45:50",
      action: "Password Change",
      details: "User changed their password",
    },
  ];
  const [twoFactor, setTwoFactor] = useState(true);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [accountFreeze, setAccountFreeze] = useState(false);
  const [cardLoadingFee, setCardLoadingFee] = useState("2.5");
  // Track which tab is active
  const [activeTab, setActiveTab] = useState("cards");

  // Tab labels
  const tabs = [
    { key: "cards", label: "Cards" },
    { key: "transactions", label: "Transactions" },
    { key: "deposits", label: "Deposits" },
    { key: "logs", label: "Logs" },
  ];
  return (
    <div className="min-h-screen  ">
      <div className="mx-auto max-w-7xl">
        {/* Top Section: User Information */}
        <div className="bg-white border rounded-md p-6 shadow-sm">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">
            User Information
          </h2>
          <div className="grid gap-4 md:grid-cols-2">
            {/* Name */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Name
              </label>
              <div className="flex items-center">
                <input
                  type="text"
                  value={user.name}
                  readOnly
                  className="block w-full border border-gray-300 rounded px-3 py-2 text-sm text-gray-700 
                         focus:outline-none focus:ring-1 focus:ring-gray-500 focus:border-gray-500"
                />
                {user.nameVerified && (
                  <span className="ml-2 inline-flex items-center px-2 py-1 text-xs font-medium text-green-800 bg-green-100 border border-green-200 rounded-full">
                    Verified
                  </span>
                )}
              </div>
            </div>

            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <div className="flex items-center">
                <input
                  type="text"
                  value={user.email}
                  readOnly
                  className="block w-full border border-gray-300 rounded px-3 py-2 text-sm text-gray-700 
                         focus:outline-none focus:ring-1 focus:ring-gray-500 focus:border-gray-500"
                />
                {user.emailVerified && (
                  <span className="ml-2 inline-flex items-center px-2 py-1 text-xs font-medium text-green-800 bg-green-100 border border-green-200 rounded-full">
                    Verified
                  </span>
                )}
              </div>
            </div>

            {/* Phone */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Phone
              </label>
              <input
                type="text"
                value={user.phone}
                readOnly
                className="block w-full border border-gray-300 rounded px-3 py-2 text-sm text-gray-700 
                       focus:outline-none focus:ring-1 focus:ring-gray-500 focus:border-gray-500"
              />
            </div>

            {/* User UUID */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                User UUID
              </label>
              <input
                type="text"
                value={user.uuid}
                readOnly
                className="block w-full border border-gray-300 rounded px-3 py-2 text-sm text-gray-700 
                       focus:outline-none focus:ring-1 focus:ring-gray-500 focus:border-gray-500"
              />
            </div>
          </div>

          {/* Edit Button */}
          <div className="mt-4">
            <button
              type="button"
              className="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 
                     bg-white border border-gray-300 rounded hover:bg-gray-50"
            >
              Edit User Details
            </button>
          </div>
        </div>

        <div className="bg-white border my-6 rounded-md shadow-sm p-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-1">
            Account Balance
          </h2>
          <p className="text-sm text-gray-500 mb-4">
            Manage user&apos;s account balance
          </p>

          <div className="flex items-center justify-between">
            <div className="text-3xl font-bold text-gray-800">
              ${balance.toFixed(2)}
            </div>
            <div className="space-x-2">
              <button className="inline-flex items-center px-4 py-2 text-sm font-medium border-gray-200 border bg-white text-gray-900 hover:bg-gray-50 rounded ">
                + Add Funds
              </button>
              <button className="inline-flex items-center px-4 py-2 text-sm font-medium border-gray-200 border bg-white text-gray-900 hover:bg-gray-50 rounded ">
                - Subtract Funds
              </button>
            </div>
          </div>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* User Statistics */}
          <div className="bg-white border rounded-md shadow-sm p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">
              User Statistics
            </h3>
            <div className="space-y-2">
              {userStats.map((stat, index) => (
                <div key={index} className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">{stat.label}</span>
                  <span className="font-medium text-gray-800">
                    {stat.value}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Referral Statistics */}
          <div className="bg-white border rounded-md shadow-sm p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">
              Referral Statistics
            </h3>
            <div className="space-y-2">
              {referralStats.map((stat, index) => (
                <div key={index} className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">{stat.label}</span>
                  <span className="font-medium text-gray-800">
                    {stat.value}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="bg-white border my-6 rounded-md p-6 shadow-sm">
          <h2 className="text-lg font-semibold text-gray-800 mb-4">
            Additional User Controls
          </h2>

          {/* Two-Factor Authentication (2FA) */}
          <div className="flex items-start justify-between mb-4">
            <div className="mr-4">
              <p className="text-sm font-medium text-gray-700">
                Two-Factor Authentication (2FA)
              </p>
              <p className="text-xs text-gray-500">
                Extra layer of security for the user’s account
              </p>
            </div>
            {/* Toggle + "Enabled" label */}
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-700">
                {twoFactor ? "Enabled" : "Disabled"}
              </span>
              <button
                type="button"
                onClick={() => setTwoFactor(!twoFactor)}
                className={`relative inline-flex h-5 w-10 items-center rounded-full transition-colors ${
                  twoFactor ? "bg-green-500" : "bg-gray-300"
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    twoFactor ? "translate-x-5" : "translate-x-1"
                  }`}
                />
              </button>
            </div>
          </div>

          {/* Email Notifications */}
          <div className="flex items-start justify-between mb-4">
            <div className="mr-4">
              <p className="text-sm font-medium text-gray-700">
                Email Notifications
              </p>
              <p className="text-xs text-gray-500">
                Send email notifications for account activities
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-700">
                {emailNotifications ? "On" : "Off"}
              </span>
              <button
                type="button"
                onClick={() => setEmailNotifications(!emailNotifications)}
                className={`relative inline-flex h-5 w-10 items-center rounded-full transition-colors ${
                  emailNotifications ? "bg-green-500" : "bg-gray-300"
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    emailNotifications ? "translate-x-5" : "translate-x-1"
                  }`}
                />
              </button>
            </div>
          </div>

          {/* Account Freeze */}
          <div className="flex items-start justify-between mb-4">
            <div className="mr-4">
              <p className="text-sm font-medium text-gray-700">
                Account Freeze
              </p>
              <p className="text-xs text-gray-500">
                Temporarily freeze all account activities
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-700">
                {accountFreeze ? "On" : "Off"}
              </span>
              <button
                type="button"
                onClick={() => setAccountFreeze(!accountFreeze)}
                className={`relative inline-flex h-5 w-10 items-center rounded-full transition-colors ${
                  accountFreeze ? "bg-green-500" : "bg-gray-300"
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    accountFreeze ? "translate-x-5" : "translate-x-1"
                  }`}
                />
              </button>
            </div>
          </div>

          {/* Spending Limits */}
          <div className="flex items-start justify-between mb-4">
            <div className="mr-4">
              <p className="text-sm font-medium text-gray-700">
                Spending Limits
              </p>
              <p className="text-xs text-gray-500">
                Set daily/monthly spending limits
              </p>
            </div>
            <button
              type="button"
              className="inline-flex items-center px-3 py-1 text-sm font-medium text-gray-700 bg-gray-100 border border-gray-300 rounded hover:bg-gray-200"
            >
              Configure
            </button>
          </div>

          {/* Card Loading Fee */}
          <div className="flex items-start justify-between mb-4">
            <div className="mr-4">
              <p className="text-sm font-medium text-gray-700">
                Card Loading Fee
              </p>
              <p className="text-xs text-gray-500">
                Set the fee percentage for loading cards
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <input
                type="text"
                value={cardLoadingFee}
                onChange={(e) => setCardLoadingFee(e.target.value)}
                className="w-16 px-2 py-1 border border-gray-300 rounded text-sm text-gray-700 
                       focus:outline-none focus:ring-1 focus:ring-gray-500 focus:border-gray-500"
              />
              <button
                type="button"
                className="inline-flex items-center px-3 py-1 text-sm font-medium text-gray-700 bg-gray-100 border border-gray-300 rounded hover:bg-gray-200"
              >
                Update
              </button>
            </div>
          </div>

          {/* Password Reset */}
          <div className="flex items-start justify-between mb-6">
            <div className="mr-4">
              <p className="text-sm font-medium text-gray-700">
                Password Reset
              </p>
              <p className="text-xs text-gray-500">
                Send a password reset email to the user
              </p>
            </div>
            <button
              type="button"
              className="inline-flex items-center px-3 py-1 text-sm font-medium text-gray-700 bg-gray-100 border border-gray-300 rounded hover:bg-gray-200"
            >
              Send Reset Email
            </button>
          </div>

          {/* Suspend Account Button */}
          <button
            type="button"
            className="w-full inline-flex items-center justify-center px-4 py-2 text-sm font-medium text-white bg-red-600 rounded hover:bg-red-700"
          >
            Suspend Account
          </button>
        </div>
<div className="px-2">

        <div className="border-b mb-6">
          <nav className="flex space-x-6 " aria-label="Tabs">
            {tabs.map((tab) => (
              <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`pb-2 text-sm font-medium ${
                  activeTab === tab.key
                    ? "text-gray-900 border-b-2 border-gray-900"
                    : "text-gray-500 hover:text-gray-700"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        {/* Conditionally Render Content */}
        {activeTab === "cards" && <CardsTab />}
        {activeTab === "transactions" && <TransactionsTab />}
        {activeTab === "deposits" && <DepositsTab />}
        {activeTab === "logs" && <LogsTab />}
            </div>
      </div>
    </div>
  );
}

function CardsTab() {
  return (
    <div className="bg-white border rounded-md p-6 shadow-sm">
      <h2 className="text-lg font-semibold text-gray-800 mb-1">User Cards</h2>
      <p className="text-sm text-gray-500 mb-4">
        Manage user&apos;s cards and balances
      </p>

      {/* Table Head */}
      <div className="hidden md:grid md:grid-cols-4 text-sm font-medium text-gray-500 border-b">
        <div className="py-2">Card Number</div>
        <div className="py-2">Balance</div>
        <div className="py-2">Status</div>
        <div className="py-2">Actions</div>
      </div>

      {/* Table Body */}
      {cardData.map((card, index) => (
        <div
          key={index}
          className="grid grid-cols-1 md:grid-cols-4 gap-y-1 py-3 border-b last:border-0"
        >
          {/* Card Number */}
          <div className="md:py-0">
            <span className="font-medium text-gray-700 md:hidden">
              Card Number:{" "}
            </span>
            <span className="text-gray-900">{card.number}</span>
          </div>

          {/* Balance */}
          <div className="md:py-0">
            <span className="font-medium text-gray-700 md:hidden">
              Balance:{" "}
            </span>
            <span className="text-gray-900">${card.balance.toFixed(2)}</span>
          </div>

          {/* Status */}
          <div className="md:py-0">
            <span className="font-medium text-gray-700 md:hidden">
              Status:{" "}
            </span>
            {card.status === "Active" ? (
              <span className="inline-flex items-center px-2 py-1 text-xs font-medium text-green-800 bg-green-100 border border-green-200 rounded-full">
                Active
              </span>
            ) : (
              <span className="inline-flex items-center px-2 py-1 text-xs font-medium text-red-800 bg-red-100 border border-red-200 rounded-full">
                Blocked
              </span>
            )}
          </div>

          {/* Actions */}
          <div className="flex flex-wrap gap-2 mt-2 md:mt-0">
            {card.status === "Active" ? (
              <>
                <button className="px-3 py-1 text-xs font-medium text-white bg-blue-600 rounded hover:bg-blue-700">
                  + Add Funds
                </button>
                <button className="px-3 py-1 text-xs font-medium text-white bg-red-600 rounded hover:bg-red-700">
                  - Subtract Funds
                </button>
                <button className="px-3 py-1 text-xs font-medium text-white bg-gray-600 rounded hover:bg-gray-700">
                  Block
                </button>
              </>
            ) : (
              <button className="px-3 py-1 text-xs font-medium text-white bg-green-600 rounded hover:bg-green-700">
                Unblock
              </button>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

/* =====================
   TRANSACTIONS TAB
===================== */
function TransactionsTab() {
  return (
    <div className="bg-white border rounded-md p-6 shadow-sm">
      <h2 className="text-lg font-semibold text-gray-800 mb-2">Transactions</h2>
      <p className="text-sm text-gray-500 mb-4">
        This is where you display the user’s transaction history.
      </p>
      {/* Replace with your transaction table or UI */}
      <div className="text-sm text-gray-600">No transactions found.</div>
    </div>
  );
}

/* =====================
   DEPOSITS TAB
===================== */
function DepositsTab() {
  return (
    <div className="bg-white border rounded-md p-6 shadow-sm">
      <h2 className="text-lg font-semibold text-gray-800 mb-2">Deposits</h2>
      <p className="text-sm text-gray-500 mb-4">
        This is where you display the user’s deposit history or deposit methods.
      </p>
      {/* Replace with your deposit table or UI */}
      <div className="text-sm text-gray-600">No deposits found.</div>
    </div>
  );
}

/* =====================
   LOGS TAB
===================== */
function LogsTab() {
  return (
    <div className="bg-white border rounded-md p-6 shadow-sm">
      <h2 className="text-lg font-semibold text-gray-800 mb-2">Logs</h2>
      <p className="text-sm text-gray-500 mb-4">
        This is where you display the user’s logs or activity records.
      </p>
      {/* Replace with your logs table or UI */}
      <div className="text-sm text-gray-600">No logs found.</div>
    </div>
  );
}
