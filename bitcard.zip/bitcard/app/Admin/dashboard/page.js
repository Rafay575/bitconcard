"use client"

import React from 'react'
import ProtectedRoute from "@/components/ProtectedRoute";
const page = () => {
  const tableData = [
    { date: '2023-06-09', cardsCreated: 12, usersRegistered: 20, revenue: '$2,500' },
    { date: '2023-06-10', cardsCreated: 15, usersRegistered: 23, revenue: '$2,750' },
    { date: '2023-06-11', cardsCreated: 18, usersRegistered: 25, revenue: '$3,000' },
    { date: '2023-06-12', cardsCreated: 20, usersRegistered: 30, revenue: '$3,250' },
    { date: '2023-06-13', cardsCreated: 22, usersRegistered: 32, revenue: '$3,500' },
    { date: '2023-06-14', cardsCreated: 24, usersRegistered: 35, revenue: '$3,750' },
    { date: '2023-06-15', cardsCreated: 26, usersRegistered: 37, revenue: '$4,000' },
  ];
  return (
    <ProtectedRoute requiredRole="admin">
    <div>
         <div className="grid  grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {/* Card 1: Users */}
            <div className="bg-white p-4 rounded-lg shadow">
              <p className="text-gray-600">Users</p>
              <h2 className="text-2xl font-bold">10,482</h2>
              <p className="text-sm text-green-600">+20 from last month</p>
            </div>
            {/* Card 2: Total Loaded */}
            <div className="bg-white p-4 rounded-lg shadow">
              <p className="text-gray-600">Total Loaded</p>
              <h2 className="text-2xl font-bold">$1,234,567</h2>
              <p className="text-sm text-green-600">+1,234 from last week</p>
            </div>
            {/* Card 3: Revenue */}
            <div className="bg-white p-4 rounded-lg shadow">
              <p className="text-gray-600">Revenue</p>
              <h2 className="text-2xl font-bold">$534,982</h2>
              <p className="text-sm text-green-600">+2,500 from last month</p>
            </div>
            {/* Card 4: Cards Created */}
            <div className="bg-white p-4 rounded-lg shadow">
              <p className="text-gray-600">Cards Created</p>
              <h2 className="text-2xl font-bold">15,723</h2>
              <p className="text-sm text-green-600">+500 from last week</p>
            </div>
          </div>

          {/* Last 7 days statistics */}
          <div className="bg-white  rounded-lg shadow p-4">
            <h2 className="text-xl font-bold mb-4">Last 7 Days Statistics</h2>
            <div className="overflow-x-auto">
              <table className="min-w-full table-auto">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-4 py-2 text-left text-gray-600">Date</th>
                    <th className="px-4 py-2 text-left text-gray-600">Cards Created</th>
                    <th className="px-4 py-2 text-left text-gray-600">Users Registered</th>
                    <th className="px-4 py-2 text-left text-gray-600">Revenue</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {tableData.map((row, index) => (
                      <tr key={index}>
                      <td className="px-4 py-2 whitespace-nowrap">{row.date}</td>
                      <td className="px-4 py-2 whitespace-nowrap">{row.cardsCreated}</td>
                      <td className="px-4 py-2 whitespace-nowrap">{row.usersRegistered}</td>
                      <td className="px-4 py-2 whitespace-nowrap">{row.revenue}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          <div className="bg-white mt-5 rounded-lg shadow p-4">
            <h2 className="text-xl font-bold mb-4">Last 7 Days Statistics</h2>
            <div className="overflow-x-auto">
              <table className="min-w-full table-auto">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-4 py-2 text-left text-gray-600">Date</th>
                    <th className="px-4 py-2 text-left text-gray-600">Cards Created</th>
                    <th className="px-4 py-2 text-left text-gray-600">Users Registered</th>
                    <th className="px-4 py-2 text-left text-gray-600">Revenue</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {tableData.map((row, index) => (
                      <tr key={index}>
                      <td className="px-4 py-2 whitespace-nowrap">{row.date}</td>
                      <td className="px-4 py-2 whitespace-nowrap">{row.cardsCreated}</td>
                      <td className="px-4 py-2 whitespace-nowrap">{row.usersRegistered}</td>
                      <td className="px-4 py-2 whitespace-nowrap">{row.revenue}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
    </div>
    </ProtectedRoute>
  )
}

export default page