"use client";

import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

// Helper to map status strings to shadcn/ui badge variants
function getStatusVariant(status) {
  switch (status) {
    case "Completed":
      return "success";     // Green
    case "Pending":
      return "secondary";   // Gray or yellowish
    case "Failed":
      return "destructive"; // Red
    default:
      return "secondary";
  }
}

export default function TransactionsPage() {
  // Sample transaction data
  const initialTransactions = [
    {
      id: "TRX001",
      user: "John Doe",
      amount: 500.0,
      type: "Account Load",
      dateTime: "2023-06-15 19:30:00",
      status: "Completed",
    },
    {
      id: "TRX002",
      user: "Jane Smith",
      amount: 300.0,
      type: "Account Load",
      dateTime: "2023-06-15 18:00:00",
      status: "Pending",
    },
    {
      id: "TRX003",
      user: "Bob Johnson",
      amount: 1000.0,
      type: "Account Load",
      dateTime: "2023-06-15 17:00:00",
      status: "Completed",
    },
    {
      id: "TRX004",
      user: "Alice Brown",
      amount: 150.0,
      type: "Card Creation",
      dateTime: "2023-06-15 16:30:00",
      status: "Completed",
    },
    {
      id: "TRX005",
      user: "Charlie Davis",
      amount: 75.0,
      type: "Account Load",
      dateTime: "2023-06-15 15:00:00",
      status: "Failed",
    },
    {
      id: "TRX006",
      user: "Eva White",
      amount: 250.0,
      type: "Account Load",
      dateTime: "2023-06-15 14:00:00",
      status: "Completed",
    },
    {
      id: "TRX007",
      user: "Frank Miller",
      amount: 600.0,
      type: "Account Load",
      dateTime: "2023-06-15 13:00:00",
      status: "Pending",
    },
    {
      id: "TRX008",
      user: "George Hall",
      amount: 350.0,
      type: "Account Load",
      dateTime: "2023-06-15 12:00:00",
      status: "Completed",
    },
  ];

  // Search state
  const [searchQuery, setSearchQuery] = useState("");

  // Filter transactions by ID, user, type, or date/time
  const filteredTransactions = initialTransactions.filter((tx) => {
    const q = searchQuery.toLowerCase();
    return (
      tx.id.toLowerCase().includes(q) ||
      tx.user.toLowerCase().includes(q) ||
      tx.type.toLowerCase().includes(q) ||
      tx.dateTime.toLowerCase().includes(q)
    );
  });

  return (
    <div className="bg-gray-50 min-h-screen p-6">
      <div className="mx-auto max-w-6xl">
        {/* Search bar */}
        <div className="mb-4">
          <Input
            placeholder="Search transactions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        {/* Table container */}
        <div className="bg-white border rounded-md shadow-sm p-4">
          <h2 className="text-xl font-semibold mb-4">Recent Transactions</h2>

          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50 border-b">
                <TableHead className="px-4 py-2 text-gray-600">ID</TableHead>
                <TableHead className="px-4 py-2 text-gray-600">User</TableHead>
                <TableHead className="px-4 py-2 text-gray-600">Amount</TableHead>
                <TableHead className="px-4 py-2 text-gray-600">Type</TableHead>
                <TableHead className="px-4 py-2 text-gray-600">Date/Time</TableHead>
                <TableHead className="px-4 py-2 text-gray-600">Status</TableHead>
              </TableRow>
            </TableHeader>

            <TableBody>
              {filteredTransactions.map((tx) => (
                <TableRow key={tx.id} className="border-b last:border-0">
                  <TableCell className="px-4 py-3">{tx.id}</TableCell>
                  <TableCell className="px-4 py-3">{tx.user}</TableCell>
                  <TableCell className="px-4 py-3">${tx.amount.toFixed(2)}</TableCell>
                  <TableCell className="px-4 py-3">{tx.type}</TableCell>
                  <TableCell className="px-4 py-3">{tx.dateTime}</TableCell>
                  <TableCell className="px-4 py-3">
                    <Badge variant={getStatusVariant(tx.status)}>
                      {tx.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}

              {filteredTransactions.length === 0 && (
                <TableRow>
                  <TableCell
                    colSpan={6}
                    className="px-4 py-3 text-center text-sm text-gray-500"
                  >
                    No transactions found.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}
