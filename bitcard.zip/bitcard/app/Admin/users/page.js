"use client";
import { useRouter } from "next/navigation";
import React, { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

// Helper to map user statuses to badge variants
function getStatusVariant(status) {
  switch (status) {
    case "Active":
      return "success";     // Green
    case "Suspended":
      return "destructive"; // Red
    case "Inactive":
      return "secondary";   // Grayish
    default:
      return "secondary";
  }
}

export default function UserSearchPage() {
  const [users, setUsers] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const router = useRouter();
  // Number of rows per page
  const pageSize = 5;

  // Fetch user data from our new API
  useEffect(() => {
    async function fetchData() {
      try {
        const response = await fetch("http://localhost:3001/api/users");
        const data = await response.json();
        setUsers(data);
      } catch (error) {
        console.error("Error fetching users:", error);
      }
    }
    fetchData();
  }, []);

  // Filter users by name or email
  const filteredUsers = users.filter((user) => {
    const q = searchQuery.toLowerCase();
    return (
      user.name.toLowerCase().includes(q) ||
      user.email.toLowerCase().includes(q)
    );
  });

  // Pagination calculations
  const totalPages = Math.ceil(filteredUsers.length / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const currentUsers = filteredUsers.slice(startIndex, startIndex + pageSize);

  // Handle page changes
  const handlePageChange = (page) => {
    setCurrentPage(page);
  };
  const handlePrevious = () => {
    if (currentPage > 1) setCurrentPage((prev) => prev - 1);
  };
  const handleNext = () => {
    if (currentPage < totalPages) setCurrentPage((prev) => prev + 1);
  };

  // Build array of page numbers for pagination
  const pages = Array.from({ length: totalPages }, (_, i) => i + 1);

  return (
    <div className="bg-gray-50 min-h-screen p-6">
      <div className="mx-auto max-w-6xl">
        {/* Heading */}
        <h1 className="text-2xl font-semibold tracking-tight mb-1">
          User Search
        </h1>
        <p className="text-sm text-gray-500 mb-4">
          Search and manage user accounts
        </p>

        {/* Search Input */}
        <div className="max-w-sm mb-6">
          <Input
            placeholder="Search users..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1); // Reset to page 1 on new search
            }}
          />
        </div>

        {/* Table Container */}
        <div className="bg-white border rounded-md shadow-sm">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50 border-b">
                <TableHead className="px-4 py-2 text-gray-600">Name</TableHead>
                <TableHead className="px-4 py-2 text-gray-600">Email</TableHead>
                <TableHead className="px-4 py-2 text-gray-600">Status</TableHead>
                <TableHead className="px-4 py-2 text-gray-600">Balance</TableHead>
                <TableHead className="px-4 py-2 text-gray-600">Last Login</TableHead>
                <TableHead className="px-4 py-2 text-gray-600">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {currentUsers.map((user, idx) => (
                <TableRow key={idx} className="border-b last:border-0">
                  <TableCell className="px-4 py-3">{user.name}</TableCell>
                  <TableCell className="px-4 py-3">{user.email}</TableCell>
                  <TableCell className="px-4 py-3">
                    <Badge variant={getStatusVariant(user.status)}>
                      {user.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="px-4 py-3">
                    ${user.balance}
                  </TableCell>
                  <TableCell className="px-4 py-3">{user.lastLogin}</TableCell>
                  <TableCell className="px-4 py-3">
                  <Button
        className="border-gray-200 border bg-white text-gray-900 hover:bg-gray-50"
        onClick={() => router.push(`/Admin/UserProfilePage`)}
      >
        View Details
      </Button>
                  </TableCell>
                </TableRow>
              ))}

              {/* If no users found */}
              {filteredUsers.length === 0 && (
                <TableRow>
                  <TableCell
                    colSpan={6}
                    className="px-4 py-3 text-center text-sm text-gray-500"
                  >
                    No users found.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>

        {/* Pagination */}
        {filteredUsers.length > 0 && (
          <div className="flex items-center justify-center mt-4 space-x-2">
            <Button
              variant="outline"
              disabled={currentPage === 1}
              onClick={handlePrevious}
            >
              Previous
            </Button>

            {pages.map((page) => (
              <Button
                key={page}
                variant={page === currentPage ? "default" : "outline"}
                onClick={() => handlePageChange(page)}
              >
                {page}
              </Button>
            ))}

            <Button
              variant="outline"
              disabled={currentPage === totalPages}
              onClick={handleNext}
            >
              Next
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
