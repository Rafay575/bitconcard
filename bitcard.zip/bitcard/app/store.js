"use client";

import { configureStore, createSlice } from "@reduxjs/toolkit";

const getLocalStorageItem = (key) => {
  if (typeof window !== "undefined") {
    return localStorage.getItem(key);
  }
  return null;
};

const setLocalStorageItem = (key, value) => {
  if (typeof window !== "undefined") {
    localStorage.setItem(key, value);
  }
};

const removeLocalStorageItem = (key) => {
  if (typeof window !== "undefined") {
    localStorage.removeItem(key);
  }
};

// Load initial data from localStorage
const initialToken = getLocalStorageItem("token");
const initialUserString = getLocalStorageItem("user");
const initialUser = initialUserString ? JSON.parse(initialUserString) : null;

const initialState = {
  token: initialToken,
  user: initialUser,
  isLoggedIn: !!initialToken,
};

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    loginSuccess(state, action) {
      const { token, user } = action.payload;
      state.token = token;
      state.user = user;
      state.isLoggedIn = true;

      setLocalStorageItem("token", token);
      setLocalStorageItem("user", JSON.stringify(user));
    },
    logout(state) {
      state.token = null;
      state.user = null;
      state.isLoggedIn = false;

      removeLocalStorageItem("token");
      removeLocalStorageItem("user");
    },
  },
});

export const { loginSuccess, logout } = authSlice.actions;

const store = configureStore({
  reducer: {
    auth: authSlice.reducer,
  },
});

export default store;
