// middleware.js
import { NextResponse } from 'next/server';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret';

export function middleware(request) {
  const { pathname } = request.nextUrl;

  // Protect all routes under /protected
  if (pathname.startsWith('/protected')) {
    const token = request.cookies.get('token');
    if (!token) {
      return NextResponse.redirect(new URL('/login', request.url));
    }
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      // You could add role-based logic here if needed
    } catch (err) {
      return NextResponse.redirect(new URL('/login', request.url));
    }
  }

  // Protect admin routes: only allow if role === 1
  if (pathname.startsWith('/Admin')) {
    const token = request.cookies.get('token');
    if (!token) {
      return NextResponse.redirect(new URL('/login', request.url));
    }
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      if (decoded.role !== 1) {
        return NextResponse.redirect(new URL('/', request.url));
      }
    } catch (err) {
      return NextResponse.redirect(new URL('/login', request.url));
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/protected/:path*', '/Admin/:path*'],
};
