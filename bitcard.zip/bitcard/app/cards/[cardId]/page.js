"use client";

import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils"; // shadcn utility for conditional classes, if needed
import Navbar from "@/components/Navbar";

export default function CardDetailsPage() {
  // Mock card data
  const card = {
    balance: 500.0,
    status: "Active",
    last4: "1111",
    exp: "12/25",
  };

  // Mock usage/limit data
  const monthlyDepositUsed = 2000;
  const monthlyDepositLimit = 3000;
  const depositUsagePercent = (monthlyDepositUsed / monthlyDepositLimit) * 100;

  // Mock transaction history
  const transactions = [
    {
      id: 1,
      merchant: "Starbucks - Coffee Shop",
      website: "www.starbucks.com",
      dateTime: "2023-06-25 15:51",
      amount: -60.0,
      type: "debit", // or "credit", "recurring", etc.
    },
    {
      id: 2,
      merchant: "Target - Retail",
      website: "www.target.com",
      dateTime: "2023-06-25 15:21",
      amount: -93.0,
      type: "debit",
    },
    {
      id: 3,
      merchant: "Walmart - Retail",
      website: "www.walmart.com",
      dateTime: "2023-06-25 14:51",
      amount: -87.0,
      type: "debit",
    },
    {
      id: 4,
      merchant: "Amazon - Online Retail",
      website: "www.amazon.com",
      dateTime: "2023-06-25 13:25",
      amount: 150.0,
      type: "credit",
    },
    {
      id: 5,
      merchant: "Amazon - Online Retail",
      website: "www.amazon.com",
      dateTime: "2023-06-25 13:00",
      amount: -25.0,
      type: "recurring",
    },
  ];

  // Helper to style amounts
  function formatAmount(amount) {
    const isNegative = amount < 0;
    const absoluteValue = Math.abs(amount).toFixed(2);
    return `${isNegative ? "-" : "+"}$${absoluteValue}`;
  }

  // Helper to get a badge variant for transaction type
  function getTransactionBadge(type) {
    switch (type) {
      case "debit":
        return "destructive"; // Red
      case "credit":
        return "success"; // Green
      case "recurring":
        return "secondary"; // Gray/purple
      default:
        return "secondary";
    }
  }

  return (
    <>
          <Navbar />
    <div className=" bg-gray-50 p-6">
      <div className="mx-auto max-w-7xl">
        {/* Page Heading */}
        <h1 className="text-2xl font-semibold tracking-tight">Card Details</h1>
        <p className="text-sm text-gray-500 mb-6">
          Card ending in {card.last4}
        </p>

        {/* Main Layout: 2 columns on desktop */}
        <div className="flex flex-col md:flex-row gap-6">
          {/* Left Column */}
          <div className="space-y-4">
            {/* The Black Card Preview */}
            <div className="relative rounded-lg bg-black text-white p-6 shadow-sm h-40 w-full flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-300">Balance</p>
                  <p className="text-2xl font-semibold">${card.balance.toFixed(2)}</p>
                </div>
                <Badge variant="success">{card.status}</Badge>
              </div>
              <div className="flex items-center justify-between text-sm">
                <div>
                  <p className="text-gray-300">**** **** **** {card.last4}</p>
                  <p className="text-gray-400">Exp: {card.exp}</p>
                </div>
                <div className="text-gray-300">
                  {/* Card brand / logo placeholder */}
                  <span>CVC</span>
                </div>
              </div>
            </div>

            {/* Delete Card Action */}
            <button className="text-red-500 text-sm hover:underline">
              Delete Card
            </button>

            {/* My Cash Card / Actions */}
            <div className="space-y-2">
              <p className="text-sm font-semibold">My Cash Card</p>
              <div className="flex flex-wrap items-center gap-2">
                <Button variant="default">Load Money</Button>
                <Button variant="outline">Show CVC</Button>
                <Button variant="outline">3DS Code</Button>
              </div>
            </div>

            {/* Monthly Deposit Limit */}
            <div className="space-y-2">
              <p className="text-sm font-semibold">Monthly Deposit Limit</p>
              <p className="text-sm text-gray-500">
                ${monthlyDepositUsed.toLocaleString()} used of $
                {monthlyDepositLimit.toLocaleString()}
              </p>
              <Progress value={depositUsagePercent} className="w-full" />
              {/* Example of some extra text if needed */}
              <p className="text-xs text-gray-400">
                {depositUsagePercent.toFixed(0)}% of limit used
              </p>
            </div>
          </div>

          {/* Right Column: Transaction History */}
          <div className="space-y-4 flex-1">
            <h2 className="text-lg font-semibold">Transaction History</h2>

            <div className="bg-white rounded-md border shadow-sm p-4 space-y-2">
              {transactions.map((tx) => {
                const amountClass =
                  tx.amount < 0 ? "text-red-600" : "text-green-600";
                return (
                  <div
                    key={tx.id}
                    className="flex items-center justify-between py-2 border-b last:border-0"
                  >
                    <div className="space-y-0.5">
                      <p className="font-medium">{tx.merchant}</p>
                      <p className="text-xs text-gray-400">{tx.website}</p>
                      <p className="text-xs text-gray-400">{tx.dateTime}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <p className={cn("font-semibold", amountClass)}>
                        {formatAmount(tx.amount)}
                      </p>
                      <Badge variant={getTransactionBadge(tx.type)}>
                        {tx.type.charAt(0).toUpperCase() + tx.type.slice(1)}
                      </Badge>
                    </div>
                  </div>
                );
              })}

              {/* If no transactions */}
              {transactions.length === 0 && (
                <p className="text-sm text-gray-500">No transactions found.</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
    </>

  );
}
