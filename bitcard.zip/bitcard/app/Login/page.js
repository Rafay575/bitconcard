"use client"
import LoginComponent from '@/components/LoginComponent'
import React from 'react'
function page() {
  return (
    <div>
      <LoginComponent />
    </div>
  )
}

export default page