

import React, { useState } from 'react';

const CreateCardModal = ({ onClose }) => {
  const [showFeatures, setShowFeatures] = useState(false);
  const [codeDigits, setCodeDigits] = useState(['', '', '', '']);

  const toggleFeatures = () => {
    setShowFeatures(!showFeatures);
  };

  if (showFeatures) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
        <div className="bg-white rounded-lg p-8 w-full max-w-md relative">
          <div className="flex justify-center items-center mb-6">
            <h2 className="text-xl font-semibold">Create a new card</h2>
            <button onClick={toggleFeatures} className="absolute  right-8  text-gray-500 hover:text-gray-700">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <div className="mb-6">
            <h3 className="text-lg text-center font-semibold mb-4">Key Features</h3>
            <ul className="list-disc text-black list-inside space-y-2 my-10">
              <li>Instant virtual card creation</li>
              <li>Secure 3DS authentication for online purchases</li>
              <li>Customizable spending limits</li>
              <li>Real-time transaction notifications</li>
              <li>24/7 customer support</li>
              <li>Integration with major mobile wallets</li>
              <li>Zero liability protection for unauthorized charges</li>
            </ul>
          </div>

          <p className="text-sm text-gray-700 mb-6">
            Our virtual card offers a secure and flexible way to manage your online purchases and subscriptions. With
            instant creation and customizable features, you're in control of your spending like never before.
          </p>

          <button
            onClick={toggleFeatures}
            className="bg-black/80 text-white py-3 px-6 rounded-md w-full font-semibold"
          >
            Back to Card Creation
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
     <div className="bg-white rounded-lg p-8 w-full max-w-md relative">
        <div className="flex justify-center items-center mb-10">
          <h2 className="text-2xl text-center font-semibold">Create a new card</h2>
          <button onClick={onClose} className="absolute right-8 text-gray-500 hover:text-gray-700">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="w-fit mx-auto  my-10">
          <label className="block text-sm text-center font-medium text-gray-700 mb-2">
            Enter Card Label (Optional)
          </label>
          <input
            type="text"
            // value={cardLabel}
            // onChange={(e) => setCardLabel(e.target.value)}
            className="border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          />
        </div>

        <div className="mb-6 w-fit text-center mx-auto">
          <label className="text-center w-full text-sm font-medium text-gray-700 mb-4">
            Enter 4-digit 3DS Code
          </label>
          <div className="flex space-x-2">
            {codeDigits.map((digit, index) => (
              <input
                key={index}
                id={`code-digit-${index}`}
                type="text"
                maxLength="1"
                value={digit}
                onChange={(e) => handleDigitChange(index, e.target.value)}
                className="border rounded-md w-12 h-12 py-2 px-3 text-center text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              />
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-6">
          <div>
            <h3 className="text-sm font-medium text-gray-700">Card Creation Fee</h3>
            <p className="text-xl font-semibold my-1">$15.00</p>
            <p className="text-xs text-gray-500">One-time fee (includes first month)</p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-700">Monthly Fee</h3>
            <p className="text-xl font-semibold my-1">$1.00</p>
            <p className="text-xs text-gray-500">Charged after the first month</p>
          </div>
        </div>

        <div className="flex items-center mt-10 justify-between">
          <button className="bg-black/80 text-white py-3 px-6 rounded-md w-full font-semibold">
            Create Card & Pay $15
          </button>
          <button  onClick={toggleFeatures} className="text-gray-500 hover:text-gray-700">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-5 w-5 ml-2"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </button>
        </div>
      </div>
       
      
    </div>
  );
};

export default CreateCardModal;