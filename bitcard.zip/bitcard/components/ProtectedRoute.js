'use client';
import { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useRouter } from 'next/navigation';
import axios from 'axios';
import { logout, loginSuccess } from '../app/store'; // adjust path as needed

/**
 * @param {Object} props
 * @param {React.ReactNode} props.children - The protected page content.
 * @param {string} props.requiredRole - "admin" or "user".
 */
export default function ProtectedRoute({ children, requiredRole }) {
  const { token, user, isLoggedIn } = useSelector((state) => state.auth);
  const dispatch = useDispatch();
  const router = useRouter();

  // Local state for verification status
  const [verified, setVerified] = useState(false);

  useEffect(() => {
    // Function to verify token
    const verifyToken = async () => {
      if (token) {
        try {
          const response = await axios.get("http://localhost:3001/api/verify", {
            headers: { Authorization: `Bearer ${token}` },
          });
          // Update Redux state with latest user info if needed
          dispatch(loginSuccess({ token, user: response.data.user }));
          // Check role-based access
          if (requiredRole === 'admin' && response.data.user.role !== 1) {
            // Not an admin trying to access an admin page – redirect (e.g., to home)
            router.push('/');
            return;
          }
          if (requiredRole === 'user' && response.data.user.role === 1) {
            // Admin trying to access a user page – redirect (e.g., to admin dashboard)
            router.push('/Admin/dashboard');
            return;
          }
          setVerified(true);
        } catch (error) {
          // If verification fails, clear auth and redirect to login
          dispatch(logout());
          router.push('/Login');
        }
      } else {
        router.push('/Login');
      }
    };

    verifyToken();
    // We run this on mount (or whenever token changes)
  }, [token, dispatch, router, requiredRole]);

  // Until verification completes, show a full‑screen preloader.
  if (!verified) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-white z-[1000]">
        <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return <>{children}</>;
}
