import React, { useState } from "react";
import { useForm } from "react-hook-form";
import toastr from "toastr";
import axios from "axios";
import { Eye, EyeOff, AlertTriangle } from "lucide-react";
import Footer from "./Footer"; // your footer component

// Redux
import { useDispatch } from "react-redux";
import { loginSuccess } from "../app/store"; // Adjust path to store.js if needed
import { useRouter } from "next/navigation"; // For redirects

export default function LoginComponent() {
  const [activeTab, setActiveTab] = useState("login");
  const sliderStyle = {
    width: "49%",
    transform: activeTab === "login" ? "translateX(2%)" : "translateX(100%)",
  };

  return (
    <>
      <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100 px-4 py-8">
        {/* Logo / Title */}
        <div className="mb-8 flex flex-col items-center">
          <div className="mb-2 h-16 w-16 bg-gray-200" />
          <h1 className="text-3xl font-bold text-gray-900">Biton Card</h1>
          <p className="text-gray-700 mt-2">
            Manage your crypto-backed debit card
          </p>
        </div>

        {/* Auth Container */}
        <div className="w-full max-w-md rounded-md bg-white p-6 shadow">
          <h2 className="mb-2 text-2xl font-semibold text-gray-900">Welcome</h2>
          <p className="text-gray-500 text-sm">
            Login or create an account to get started
          </p>

          {/* Tabs */}
          <div className="relative tab-group mt-5">
            <div
              className="flex bg-stone-100 shadow-sm p-0.5 relative rounded-lg"
              role="tablist"
            >
              {/* Animated Slider Indicator */}
              <div
                className="absolute top-1 left-0.5 h-8 bg-white text-white rounded-md shadow-sm transition-all duration-300 transform tab-indicator z-0"
                style={sliderStyle}
              ></div>

              <button
                onClick={() => setActiveTab("login")}
                className={`tab-link text-sm inline-block py-2 mx-2 w-1/2 px-4  ${
                  activeTab !== "login" ? "text-stone-800" : "text-stone-800"
                }  transition-all duration-300 relative z-10 mr-1`}
              >
                Login
              </button>
              <button
                onClick={() => setActiveTab("signup")}
                className={`tab-link text-sm inline-block py-2 mx-2 w-1/2 px-4  ${
                  activeTab === "login" ? "text-stone-800" : "text-stone-800"
                }  transition-all duration-300 relative z-10 mr-1`}
              >
                Sign Up
              </button>
            </div>

            {/* Tab Content */}
            <div className="mt-4 tab-content-container">
              {activeTab === "login" ? (
                <div
                  id="login-tab"
                  className="tab-content text-stone-500 text-sm block"
                >
                  <LoginForm />
                </div>
              ) : (
                <div
                  id="signup-tab"
                  className="tab-content text-stone-500 text-sm block"
                >
                  {/* Pass setActiveTab down */}
                  <SignupForm setActiveTab={setActiveTab} />
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Alert Box (Restricted Countries) */}
        <main className="flex-grow max-w-md">
          <div className="">
            <div className="mt-8 flex items-start rounded-md border border-gray-200 p-4">
              <AlertTriangle className="mr-2 h-12 w-12 text-yellow-600" />
              <div>
                <h3 className="mb-1 text-sm font-semibold text-gray-800">
                  Restricted Countries
                </h3>
                <p className="text-sm text-gray-600">
                  Biton Card services are not available in certain countries due
                  to regulatory restrictions. Please ensure you are not located
                  in a restricted country before signing up.
                </p>
              </div>
            </div>
          </div>
        </main>
      </div>
      <Footer />
    </>
  );
}

/* =========================
   LOGIN FORM
========================= */
function LoginForm() {
  const [showPassword, setShowPassword] = useState(false);
  const { register, handleSubmit } = useForm();
  const dispatch = useDispatch();
  const router = useRouter(); // For redirecting

  const onSubmit = async (formData) => {
    try {
      const response = await axios.post("http://localhost:3001/api/login", {
        email: formData.email,
        password: formData.password,
      });

      toastr.success("Login successful!");
      const fullUser = {
        balance: response.data.user.balance,
        created_at: response.data.user.created_at,
        email: response.data.user.email,
        firstName: response.data.user.firstName,
        id: response.data.user.id,
        lastName: response.data.user.lastName,
        password: response.data.user.password, // Note: be cautious storing passwords
        restrictedCheck: response.data.user.restrictedCheck,
        role: response.data.user.role,
        status: response.data.user.status,
      };
      dispatch(loginSuccess({ token: response.data.token, user: fullUser }));
      
      const role = response.data.user.role;
      if (role === 0) {
        router.push("/");
      } else if (role === 1) {
        router.push("/Admin/dashboard");
      }
    } catch (error) {
      toastr.error(error?.response?.data?.error || "Login failed");
    }
  };

  return (
    <div className="">
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        {/* Email */}
        <div className="mb-3">
          <label
            htmlFor="email"
            className="block text-sm mb-1 font-medium text-gray-900"
          >
            Email
          </label>
          <input
            id="email"
            type="email"
            placeholder="name@example.com"
            className="mt-1 block w-full rounded border border-gray-300 px-3 py-3
                       focus:border-gray-500 focus:outline-none focus:ring-1 focus:ring-gray-500"
            {...register("email", { required: true })}
          />
        </div>

        {/* Password */}
        <div className="mb-3">
          <label
            htmlFor="password"
            className="block text-sm mb-1 font-medium text-gray-900"
          >
            Password
          </label>
          <div className="relative mt-1">
            <input
              id="password"
              type={showPassword ? "text" : "password"}
              placeholder="••••••••"
              className="block w-full rounded border  border-gray-300 px-3 py-3 pr-10
                         focus:border-gray-500 focus:outline-none focus:ring-1 focus:ring-gray-500"
              {...register("password", { required: true })}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 hover:text-gray-600"
            >
              {showPassword ? (
                <EyeOff className="h-5 w-5" />
              ) : (
                <Eye className="h-5 w-5" />
              )}
            </button>
          </div>
        </div>

        {/* Submit */}
        <button
          type="submit"
          className="w-full rounded bg-black px-4 py-2 text-white font-medium hover:bg-gray-900"
        >
          Login
        </button>
      </form>

      {/* Divider */}
      <div className="my-6 flex items-center justify-center">
        <div className="h-px w-full bg-gray-200" />
        <span className="mx-3 !text-xs w-full inline text-gray-400">
          OR CONTINUE WITH
        </span>
        <div className="h-px w-full bg-gray-200" />
      </div>

      {/* Social Buttons (placeholders) */}
      <div className="mb-6 flex items-center justify-center space-x-3">
        {/* GitHub Button */}
        <button className="rounded border border-gray-300 p-2 hover:bg-gray-50">
          {/* GitHub icon */}
          <svg
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="black"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="lucide lucide-github"
          >
            <path
              d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5
                     .28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2
                     c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49
                     -.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4"
            />
            <path d="M9 18c-4.51 2-5-2-7-2" />
          </svg>
        </button>
        {/* Twitter Button */}
        <button className="rounded border border-gray-300 p-2 hover:bg-gray-50">
          <svg
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="black"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="lucide lucide-twitter"
          >
            <path
              d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6
                     2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6
                     5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0
                     3-1.2 3-1.2z"
            />
          </svg>
        </button>
        {/* Facebook Button */}
        <button className="rounded border border-gray-300 p-2 hover:bg-gray-50">
          <svg
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="black"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="lucide lucide-facebook"
          >
            <path
              d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3
                     l1-4h-4V7a1 1 0 0 1 1-1h3z"
            />
          </svg>
        </button>
      </div>

      {/* Terms & Privacy */}
      <p className="text-left !leading-6 text-sm text-gray-500">
        By continuing, you agree to our{" "}
        <a href="#" className="text-blue-600 hover:underline">
          Terms of Service
        </a>{" "}
        and{" "}
        <a href="#" className="text-blue-600 hover:underline">
          Privacy Policy
        </a>
        .
      </p>
    </div>
  );
}

/* =========================
   SIGNUP FORM
========================= */
function SignupForm({ setActiveTab }) {
  const [showPassword, setShowPassword] = useState(false);

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm();

  // Simple password strength logic
  const passwordValue = watch("password") || "";
  let passwordStrength = "Very Weak";
  if (passwordValue.length >= 15) {
    passwordStrength = "Very Strong";
  } else if (passwordValue.length >= 10) {
    passwordStrength = "Strong";
  } else if (passwordValue.length >= 6) {
    passwordStrength = "Medium";
  } else if (passwordValue.length >= 3) {
    passwordStrength = "Weak";
  }

  const onSubmit = async (data) => {
    try {
      await axios.post("http://localhost:3001/api/signup", data);
      toastr.success("Sign-up successful! You can now login.");

      // After 2 seconds, switch tab to login
      setTimeout(() => {
        setActiveTab("login");
      }, 2000);
    } catch (error) {
      toastr.error(error?.response?.data?.error || "Sign-up failed");
    }
  };

  const onError = (formErrors) => {
    Object.values(formErrors).forEach((errorObj) => {
      toastr.error(errorObj.message);
    });
  };

  return (
    <div className="">
      <form onSubmit={handleSubmit(onSubmit, onError)} className="space-y-4">
        {/* First & Last Name */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label
              htmlFor="firstName"
              className="block text-sm font-medium text-gray-700"
            >
              First Name
            </label>
            <input
              id="firstName"
              type="text"
              placeholder="John"
              className="mt-1 block w-full rounded border border-gray-300 px-3 py-2 
                         focus:border-gray-500 focus:outline-none focus:ring-1 focus:ring-gray-500"
              {...register("firstName", {
                required: "First name is required.",
                pattern: {
                  value: /^[A-Za-z]{3,}$/,
                  message: "Must be at least 3 letters (A–Z) with no spaces.",
                },
              })}
            />
          </div>
          <div>
            <label
              htmlFor="lastName"
              className="block text-sm font-medium text-gray-700"
            >
              Last Name
            </label>
            <input
              id="lastName"
              type="text"
              placeholder="Doe"
              className="mt-1 block w-full rounded border border-gray-300 px-3 py-2
                         focus:border-gray-500 focus:outline-none focus:ring-1 focus:ring-gray-500"
              {...register("lastName", {
                required: "Last name is required.",
                pattern: {
                  value: /^[A-Za-z]{3,}$/,
                  message: "Must be at least 3 letters (A–Z) with no spaces.",
                },
              })}
            />
          </div>
        </div>
        <p className="text-xs text-gray-500">
          This will be the name of the card holder. Only letters are allowed.
        </p>

        {/* Email */}
        <div>
          <label
            htmlFor="email"
            className="block text-sm font-medium text-gray-700"
          >
            Email
          </label>
          <input
            id="email"
            type="email"
            placeholder="name@example.com"
            className="mt-1 block w-full rounded border border-gray-300 px-3 py-2 
                       focus:border-gray-500 focus:outline-none focus:ring-1 focus:ring-gray-500"
            {...register("email", {
              required: "Email is required.",
              pattern: {
                value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                message: "Please enter a valid email address.",
              },
            })}
          />
        </div>

        {/* Password */}
        <div>
          <label
            htmlFor="password"
            className="block text-sm font-medium text-gray-700"
          >
            Password
          </label>
          <div className="relative mt-1">
            <input
              id="password"
              type={showPassword ? "text" : "password"}
              placeholder="••••••••"
              className="block w-full rounded border border-gray-300 px-3 py-2 pr-10 
                         focus:border-gray-500 focus:outline-none focus:ring-1 focus:ring-gray-500"
              {...register("password", {
                required: "Password is required.",
              })}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 hover:text-gray-600"
            >
              {showPassword ? (
                <EyeOff className="h-5 w-5" />
              ) : (
                <Eye className="h-5 w-5" />
              )}
            </button>
          </div>

          {/* Password Strength Indicator */}
          <div className="mt-2 h-1 w-full bg-red-500" />
          <p className="text-xs text-gray-500 mt-1">
            Password strength: {passwordStrength}
          </p>
        </div>

        {/* Confirm Password */}
        <div>
          <label
            htmlFor="confirmPassword"
            className="block text-sm font-medium text-gray-700"
          >
            Confirm Password
          </label>
          <input
            id="confirmPassword"
            type="password"
            placeholder="••••••••"
            className="mt-1 block w-full rounded border border-gray-300 px-3 py-2 
                       focus:border-gray-500 focus:outline-none focus:ring-1 focus:ring-gray-500"
            {...register("confirmPassword", {
              required: "Please confirm your password.",
              validate: (value) =>
                value === watch("password") || "Passwords do not match.",
            })}
          />
        </div>

        {/* Restricted Country Checkbox */}
        <div className="flex items-center">
          <input
            id="restrictedCheck"
            type="checkbox"
            className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-gray-500"
            {...register("restrictedCheck", {
              required:
                "You must confirm you are not located in a restricted country.",
            })}
          />
          <label
            htmlFor="restrictedCheck"
            className="ml-2 text-sm text-gray-700"
          >
            I confirm that I am not located in a restricted country
          </label>
        </div>

        {/* Sign Up Button */}
        <button
          type="submit"
          className="w-full rounded bg-black px-4 py-2 font-medium text-white hover:bg-gray-900"
        >
          Sign Up
        </button>
      </form>

      {/* Divider */}
      <div className="my-6 flex items-center justify-center">
        <div className="h-px w-full bg-gray-200" />
        <span className="mx-3 !text-xs w-full inline text-gray-400">
          OR CONTINUE WITH
        </span>
        <div className="h-px w-full bg-gray-200" />
      </div>

      {/* Social Buttons (placeholders) */}
      <div className="mb-6 flex items-center justify-center space-x-3">
        <button className="rounded border border-gray-300 p-2 hover:bg-gray-50">
          {/* GitHub icon */}
          <svg
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="black"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="lucide lucide-github"
          >
            <path
              d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25
                     -.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5
                     -2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35
                     0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5
                     -.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15
                     1.85v4"
            />
            <path d="M9 18c-4.51 2-5-2-7-2" />
          </svg>
        </button>
        <button className="rounded border border-gray-300 p-2 hover:bg-gray-50">
          {/* Twitter icon */}
          <svg
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="black"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="lucide lucide-twitter"
          >
            <path
              d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6
                     2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6
                     5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0
                     3-1.2 3-1.2z"
            />
          </svg>
        </button>
        <button className="rounded border border-gray-300 p-2 hover:bg-gray-50">
          {/* Facebook icon */}
          <svg
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="black"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="lucide lucide-facebook"
          >
            <path
              d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3
                     l1-4h-4V7a1 1 0 0 1 1-1h3z"
            />
          </svg>
        </button>
      </div>

      {/* Terms & Privacy */}
      <p className="text-left !leading-6 text-sm text-gray-500">
        By continuing, you agree to our{" "}
        <a href="#" className="text-blue-600 hover:underline">
          Terms of Service
        </a>{" "}
        and{" "}
        <a href="#" className="text-blue-600 hover:underline">
          Privacy Policy
        </a>
        .
      </p>
    </div>
  );
}
