import Link from "next/link";
import clsx from "clsx";

const baseStyles = {
  solid:
    " btn btn-primary normal-case rounded-full group inline-flex items-center justify-center   py-2 px-4 text-sm font-semibold focus:outline-none focus-visible:outline-2 focus-visible:outline-offset-2",
  outline:
    "group inline-flex ring-1 items-center justify-center rounded-lg py-2 px-4 text-sm focus:outline-none bg-white",
};

const variantStyles = {
  solid: {
    // slate:
    //   "bg-primary text-white hover:bg-slate-700 hover:text-slate-100 active:bg-slate-800 active:text-slate-300 focus-visible:outline-primary",
    // success:
    //   "bg-success text-white hover:text-slate-100 hover:bg-green-500 active:bg-green-800 active:text-green-100 focus-visible:outline-success",
    // white:
    //   "bg-white text-primary hover:bg-green-50 active:bg-green-200 active:text-slate-600 focus-visible:outline-white",
  },
  outline: {
    slate:
      "ring-slate-200 text-slate-700 hover:text-primary hover:ring-slate-300 active:bg-slate-100 active:text-slate-600 focus-visible:outline-success focus-visible:ring-slate-300",
    white:
      "ring-slate-700 text-white hover:ring-slate-500 active:ring-slate-700 active:text-slate-400 focus-visible:outline-white",
  },
};

export function Button({
  variant = "solid",
  color = "slate",
  className,
  href,
  ...props
}) {
  className = clsx(
    baseStyles[variant],
    variantStyles[variant][color],
    className
  );

  return href ? (
    <Link href={href} className={className} {...props} />
  ) : (
    <button className={className} {...props} />
  );
}
