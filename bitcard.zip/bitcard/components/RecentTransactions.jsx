"use client"

import React from "react"

export default function RecentTransactions() {
  // Sample data
  const transactions = [
    {
      type: "Deposit",
      description: "Deposit BTC via Ethereum",
      date: "2023-05-01 14:30",
      amount: "+$0.50",
      amountColor: "text-green-500",
      status: "Paid",
      statusColor: "bg-green-100 text-green-800",
      reference: "Trx:0x245..578"
    },
    {
      type: "Card Created",
      description: "New Card Created",
      date: "2023-05-02 10:15",
      amount: "-$15.00",
      amountColor: "text-red-500",
      status: "Completed",
      statusColor: "bg-blue-100 text-blue-800"
    },
    {
      type: "Card Funded",
      description: "Card Funded",
      date: "2023-05-03 09:25",
      amount: "+$0.50",
      amountColor: "text-green-500",
      status: "Completed",
      statusColor: "bg-blue-100 text-blue-800"
    },
    {
      type: "Deposit",
      description: "Deposit",
      date: "2023-05-04 16:10",
      amount: "+$1.20",
      amountColor: "text-green-500",
      status: "Pending Confirmation",
      statusColor: "bg-yellow-100 text-yellow-800"
    },
    {
      type: "Card Unloaded",
      description: "Card Unloaded",
      date: "2023-05-05 11:00",
      amount: "-$3.00",
      amountColor: "text-red-500",
      status: "Completed",
      statusColor: "bg-blue-100 text-blue-800"
    }
  ]

  return (
    <div className="mx-auto max-w-7xl rounded-md bg-white mt-5 shadow p-4">
      {/* Header */}
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-lg font-semibold">Recent Transactions</h2>
        <button className="rounded border border-gray-300 px-3 py-1 text-sm text-gray-600 hover:bg-gray-50">
          View All
        </button>
      </div>

      {/* Responsive Table Container */}
      <div className="overflow-x-auto rounded-lg bg-white shadow">
        <table className="w-full border-collapse text-left">
          <thead>
            <tr className="border-b bg-gray-50 text-sm text-gray-500">
              <th className="py-3 px-4">Type</th>
              <th className="py-3 px-4">Description</th>
              <th className="py-3 px-4">Date</th>
              <th className="py-3 px-4">Amount</th>
              <th className="py-3 text-center px-4">Status</th>
            </tr>
          </thead>
          <tbody className="text-sm text-gray-700">
            {transactions.map((tx, idx) => (
              <tr
                key={idx}
                className="border-b last:border-0 hover:bg-gray-50"
              >
                {/* Type */}
                <td className="py-3 px-4 font-medium">
                  {tx.type}
                </td>
                {/* Description */}
                <td className="py-3 px-4">{tx.description}</td>
                {/* Date */}
                <td className="py-3 px-4 text-gray-500">{tx.date}</td>
                {/* Amount */}
                <td className={`py-3 px-4 font-medium ${tx.amountColor}`}>
                  {tx.amount}
                </td>
                {/* Status */}
                <td className="py-3 text-center px-4">
                  <span
                    className={`inline-block rounded-full px-2 py-1 text-xs font-medium ${tx.statusColor}`}
                  >
                    {tx.status}
                  </span>
                  {/* Optional reference or additional info */}
                  {tx.reference && (
                    <p className="mt-1 text-xs text-gray-400">{tx.reference}</p>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
