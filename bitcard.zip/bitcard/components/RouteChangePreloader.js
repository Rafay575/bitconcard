'use client';
import { useEffect, useState } from 'react';
import { usePathname } from 'next/navigation';

export default function RouteChangePreloader() {
  const pathname = usePathname();
  const [mounted, setMounted] = useState(true);
  const [loading, setLoading] = useState(true);

  // Set mounted flag only on the client
  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (!mounted) return;
    // Start loading when the pathname changes
    setLoading(true);
    const timer = setTimeout(() => {
      setLoading(false);
    }, 500); // Adjust delay as needed
    return () => clearTimeout(timer);
  }, [pathname, mounted]);

  if (!mounted || !loading) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center z-[1000] bg-white">
      <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
    </div>
  );
}
