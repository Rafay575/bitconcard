import React from "react"
import { Home, Users, Globe, Settings, ArrowRight } from "lucide-react" // Icon imports

export default function Navbar() {
  return (
    <nav className="border-b bg-white" >
    <div className="flex items-center justify-between max-w-7xl mx-auto px-4 py-4">
    
      <div className="flex items-center gap-2">
        {/* Logo placeholder */}
        <div className="h-8 w-8 bg-gray-200" />
        <span className="text-xl font-bold text-gray-800">Biton Card</span>
      </div>

      {/* Right side: Icon Buttons */}
      <div className="flex items-center gap-4 space-x-4">
        {/* Home Icon */}
        <button
          type="button"
          className="p-2 text-gray-900 transition-colors hover:text-gray-900"
        >
          <Home className="h-4 w-4" />
        </button>

        {/* Users Icon */}
        <button
          type="button"
          className="p-2 text-gray-900 transition-colors hover:text-gray-900"
        >
          <Users className="h-4 w-4" />
        </button>

        {/* Globe Icon */}
        <button
          type="button"
          className="p-2 text-gray-900 transition-colors hover:text-gray-900"
        >
          <Globe className="h-4 w-4" />
        </button>

        {/* Settings Icon */}
        <button
          type="button"
          className="p-2 text-gray-900 transition-colors hover:text-gray-900"
        >
          <Settings className="h-4 w-4" />
        </button>

        {/* EN Text */}
        <span className="text-xs font-medium text-gray-700">EN</span>

        {/* Arrow Right Icon */}
        <button
          type="button"
          className="p-2 text-gray-900 transition-colors hover:text-gray-900"
        >
          <ArrowRight className="h-4 w-4" />
        </button>
      </div>
    </div>
          </nav>
  )
}
