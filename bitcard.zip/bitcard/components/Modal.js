import { Fragment, useRef, useState } from "react";
import { Dialog, Transition } from "@headlessui/react";

export default function Modal({
  children,
  isOpen = false,
  closeModal,
  title = "",
  titleClass = "",
  reload,
  className = "",
}) {
  const cancelButtonRef = useRef(null);

  return (
    <Transition.Root show={isOpen} as={Fragment}>
      <Dialog
        as="div"
        className="relative z-10 "
        initialFocus={cancelButtonRef}
        onClose={
          !reload
            ? closeModal
            : () => {
                window.location.reload();
              }
        }
      >
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" />
        </Transition.Child>

        <div className="fixed inset-0 z-10 w-screen overflow-y-auto">
          <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
              enterTo="opacity-100 translate-y-0 sm:scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 translate-y-0 sm:scale-100"
              leaveTo="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
            >
<Dialog.Panel className="relative border transform overflow-hidden rounded-xl bg-secondary text-left shadow-xl transition-all sm:my-8 sm:w-full max-w-24rem">  <div className="bg-secondary  px-4 pb-4 pt-5 my-3 sm:p-6 sm:pb-4">
                  <div className="sm:flex sm:items-start">
                    <div
                      className={` ${
                        className ? className : "text-center w-full"
                      }`}
                    >
                      <Dialog.Title
                        as="h3"
                        className={`${
                          titleClass
                            ? titleClass
                            : "text-3xl font-bold pb-4 leading-6 font-3xl text-black"
                        }`}
                      >
                        {title && title}
                      </Dialog.Title>
                      <div className="mt-4">{children && children}</div>
                    </div>
                  </div>
                </div>
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </div>
      </Dialog>
    </Transition.Root>
  );
}
