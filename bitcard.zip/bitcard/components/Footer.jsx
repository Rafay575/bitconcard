import React from "react"
import { AlertTriangle } from "lucide-react" // Lucide icon

export default function Footer() {
  return (
    <div className="flex flex-col ">
      {/* Main content area (pushes footer to bottom) */}
     

      {/* Responsive Footer */}
      <footer className="border-t border-gray-200 bg-white">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between px-4 py-6 md:flex-row">
          {/* Footer Links */}
          <nav className="mb-4 flex space-x-6 text-sm text-gray-600 md:mb-0">
            <a href="#" className="hover:text-gray-900">
              About
            </a>
            <a href="#" className="hover:text-gray-900">
              FAQ
            </a>
            <a href="#" className="hover:text-gray-900">
              Support
            </a>
          </nav>
          {/* Copyright */}
          <p className="text-sm text-gray-500">
            © 2025 Biton Card. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  )
}
