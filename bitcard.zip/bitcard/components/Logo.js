import Link from "next/link";
import React from "react";

const Logo = ({ link, noText = false }) => {
  const svgLogo = (
    <svg
      version="1.2"
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 55 52"
      width="55"
      height="52"
    >
      <defs>
        <image
          width="55"
          height="52"
          id="img1"
          href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADcAAAA0CAYAAAAuT6DoAAAAAXNSR0IArs4c6QAABklJREFUaEPdmnmMFFUQxn81ywIqV0BBjImiKLAi7MxyxQtCPEBRARXBQFSMwQj8gVfwAqNiNJioMRGjYjxiIoeAiAgoiAeiLrszu4gJhEQUESMeRA4RmS5TO704NHN09/RyWP92fd97X7/36lVVt/A/sCq0cxpGCVziwLQ6ZIPJkuNR2yC05S6oSMMAoI/AMOAvYHwSWdmo6bgR1xVt0Qa6AUMUrgWqgBaukM1pGFaPbMxerGNaXD+0w34YIDDCVgg4FzjBs9vWOHBjHbLNuwuPOXFVaHcH4sAlwCCge76jI7DoAEyoR37J5XNMiOuFdmkGgxwYKXAR0M5HLJjfFsatRvYVEO+DJmKXCrR5i8x2u1jhAqAfcHKAYWa3hMlrEQsiee2IrZydnwNQ4cBgN7olgFgAQQ2uCs+mkCl+cE0qLo6e4p6dq93zc4afSRXweTiJPO6XI2JxGusNPWJwBe4dBHTxO5kCfvuBe5LI80G4ShZ3A1q2Cc4ug8sVhgN9gTZBJlHE11EYn0JeD8oZSlwVeqKTCQRDgIHu/ROloEYdOxVuTSGLggozf9/iKtEzY5BwoL9ktl2vIPgQk7NL+c4ksjgEtgFSUFxf9NQ0DFS4DhgMdAg7UEDcdoEhtUh9QNwh7h5xGovD+WRyNxPTA+hYygAhsHUxGFeDrA+BPVRcT7RTczidzIV6JZmzdFKpxCHxG9w8saFkKdUkji4FhpZKFAG+Ng1D8+WJYfglgXZVmO1etmE4osDMaQb3ViNboyBr5Gg4cyYQWKKZeulI2/xdMHYz8nf2wBVoqxZwcVdYMQ9Jh5nUwYBioV5gDXBaGKKQmFlJmAii2XirtP+E+QpXKTyTQu4Kw39ItEygVuW+BnQKQxYEYwnwbpjqXbE4ai/3OeD6LL7bksirQfjN97B7rhIdLjAfKAtK5tdfYGYtcp/X3020FwIXep79A4xJIu/4HSOnOPcMjlJ4E2gehMynr2Uds7y+bsG6WKFnHp6dAqNrkeU+x8mfoSTQKQozI1zBPQoTcyXAVWh/hVmaaS8Ust+sOZRCLDYUtYLpVyV6v8ATRVmKO+wVuLUWmet1rUItX10GWO3nx7akYYi305ULWFBcFVruwIvWD/Qzah6fHQLja5El3uduALNA0Tkgv6VoQ2uQ7YVwRasCV6AdZKumg9qPCqNzbaMEOkLhFaB9UFLX/0OFUSlkZz58UXEGrETbCbxNptTxa5stnCeROi+gEr1Z4GWg3C9ZHj/rgI1ZjRwIvC2zAeeh7ZvDe25iXWxO1Q6MrUM25RD2gMAjEQhrpJ63C8Z570t76GvlGln6oGelM4f/nALqqpvBNdXIzzmETXeFFXs5gZ4rzEghD3lBgcQZuDcaj4HdNYdFN4W5DkzOldlXok8JHHZxB1JR2PnRJDI92yWwOAMn0MEKC4C2jWQm7AS4xdsotQ8YreFpYFKEQnJR7VeYlELsLDdYKHEGrERvkkweWm7BoRbuAHGyR+2PttkPFuqtTXEkTAWGNmYxocXZTOPoGIFuAjNqEMv/DlovtGMZvBEwwkbxAv5wO2bvliQu30ysdVEOc9y2XxQTDsqx3YHLIhfnVvbWjrPm0tG0rZGKS6ADFF4i00E7WrZNYLXC55GJ6432i4GtWJMXup63ZkHse+BrgeUCyxpzzkjEuQnwWyXkiWFW+VvAgsYHeyC1EdnlJSlZXAIdqfDCEVix34F6ha9jsMqBrwolzSXdcwZOoFaxW1RsKrOMf73AQoXlScRWy7eFXrk4Og14sAlaEVuAjxTed6CuHvnOtxqPY2Bxlk61gqkRJsB2+dcAdQIfK3yWRH4KKygbF1hcHLU88e4SB7c0KaWwwoEFdbDOm7qVyN8ADyBOYwl4UeH2kAP/CnwKfKKwrgxSNcjekFy+YL7EuZX4k8AEX6z/Of0gsN5WKA3L/TR1AvIXdC8qzs3srYdyqc+BLSAsc2DhAVi3AbEQflSsoLg4ar9WWO/E/o7LZ7sFqhVWAWvtLkoiO46KGr/RsoiwfQrWXlvpwLwU1DdFQCj1BeVcuThaAdhWzP6pzH4es2CwtAy+bA2b83WdSp1UVPhcH0KsDrI88RSBb2yrOfBFOayM+uNgVCLy8Xg/YV2h8Jh7B82JwdqmDtdNKfBfkXHFR7GLzlAAAAAASUVORK5CYII="
        />
      </defs>
      <style></style>
      <use href="#img1" transform="matrix(1,0,0,1,0,0)" />
    </svg>
  );
  if (link) {
    return (
      <Link href="/?page=1" aria-label="Home" className="flex items-center ">
        {noText ? (
          svgLogo
        ) : (
          <img src="logo.png" className="" style={{ height: "35px" }} />
        )}
      </Link>
    );
  } else {
    return (
      <div className="flex items-center ">
        {noText ? (
          svgLogo
        ) : (
          <img src="logo.png" className="" style={{ height: "35px" }} />
        )}
      </div>
    );
  }
};

export default Logo;
