// components/Modal.js
import { useState } from 'react';

export default function AddFund({ isOpen, closeModal }) {
  const [step, setStep] = useState(1);
  const [selectedCrypto, setSelectedCrypto] = useState(null);
  const [selectedNetwork, setSelectedNetwork] = useState(null);
  const [amount, setAmount] = useState(0);

  const cryptocurrencies = [
    { name: "USDT", price: 1.0 },
    { name: "USDC", price: 1.0 },
    { name: "Ethereum", price: 2000.0 },
    { name: "AVAX", price: 20.0 },
    { name: "Bitcoin Cash", price: 250.0 },
    { name: "CGPT", price: 0.5 },
    { name: "DAI", price: 1.0 },
    { name: "BNB", price: 300.0 },
    { name: "Bitcoin", price: 30000.0 },
    { name: "Dash", price: 50.0 },
    { name: "Doge", price: 0.1 },
    { name: "Verse", price: 0.01 },
    { name: "Matic", price: 1.0 },
    { name: "Litecoin", price: 100.0 },
    { name: "TRX", price: 0.08 },
    { name: "Monero", price: 150.0 },
  ];

  const networks = ['Arbitrum','Polygon', 'BSC', 'ETH',  'Avalanche','Sol', 'Tron'];

  const handleCryptoSelect = (crypto) => {
    setSelectedCrypto(crypto);
    setStep(2); // Move to the next step
  };

  const handleNetworkSelect = (network) => {
    setSelectedNetwork(network);
  };

  const handleAmountChange = (e) => {
    setAmount(e.target.value);
  };

  const handleContinue = () => {
    // Handle the continue button action, like submitting the form
    console.log("Selected Crypto:", selectedCrypto);
    console.log("Selected Network:", selectedNetwork);
    console.log("Amount:", amount);
    closeModal(); // Close modal after proceeding
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 z-50">
      <div className="bg-white p-6 rounded-lg w-full max-w-lg">
        {/* Close Button */}
        <button className="absolute top-4 right-4 text-gray-600" onClick={closeModal}>
          <span className="text-2xl">&times;</span>
        </button>

        {/* Step 1: Select Cryptocurrency */}
        {step === 1 && (
          <div className="text-center">
            <h2 className="text-2xl font-bold">Select Cryptocurrency</h2>
            <div className="grid grid-cols-3 gap-4 mt-6">
              {cryptocurrencies.map((crypto) => (
                <button
                  key={crypto.name}
                  onClick={() => handleCryptoSelect(crypto)}
                  className="px-4 py-2 rounded-md border bg-gray-100 hover:bg-gray-200 text-lg"
                >
                  {crypto.name}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Step 2: Select Network and Enter Amount */}
        {step === 2 && selectedCrypto && (
          <div className="text-center">
            <h2 className="text-2xl font-bold">Select Network</h2>
            <div className="grid grid-cols-3 gap-4 mt-6">
              {networks.map((network) => (
                <button
                  key={network}
                  onClick={() => handleNetworkSelect(network)}
                  className={`px-4 py-2 rounded-md border ${selectedNetwork === network ? 'bg-blue-500 text-white' : 'bg-gray-100'} hover:bg-blue-400 text-lg`}
                >
                  {network}
                </button>
              ))}
            </div>

            {/* Enter Amount */}
            {selectedNetwork && (
              <div className="mt-8">
                <h3 className="text-xl font-medium">Enter Amount</h3>
                <div className="flex items-center justify-center mt-4">
                  <span className="text-2xl">$</span>
                  <input
                    type="number"
                    value={amount}
                    onChange={handleAmountChange}
                    className="ml-2 w-32 p-2 rounded-md border text-lg"
                    placeholder="0"
                  />
                  <span className="text-2xl ml-2">USD</span>
                </div>
                <p className="text-sm mt-2 text-gray-500">Current exchange rate: 1 USD = $1.00 USD</p>
              </div>
            )}

            {/* Continue Button */}
            {selectedNetwork && amount > 0 && (
              <button
                onClick={handleContinue}
                className="mt-6 w-full py-3 bg-blue-500 text-white rounded-md"
              >
                Continue
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
