import React from "react";

const ButtonSpinner = ({ ml }) => {
  return (
    <span
      className={`inline-block h-5 w-5 animate-spin rounded-full border-2 border-solid border-current border-r-transparent align-[-0.125em] text-white motion-reduce:animate-[spin_1.5s_linear_infinite] ${
        ml ? "ml-2" : ""
      }`}
      role="status"
    ></span>
  );
};

export default ButtonSpinner;
