// File: pages/index.js (or app/page.js if using Next.js 13+)
// Make sure you have the Tailwind imports set up in your global CSS.
"use client"
import { useState } from 'react';

export default function Dashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Example data for the Last 7 Days Statistics table
  const tableData = [
    { date: '2023-06-09', cardsCreated: 12, usersRegistered: 20, revenue: '$2,500' },
    { date: '2023-06-10', cardsCreated: 15, usersRegistered: 23, revenue: '$2,750' },
    { date: '2023-06-11', cardsCreated: 18, usersRegistered: 25, revenue: '$3,000' },
    { date: '2023-06-12', cardsCreated: 20, usersRegistered: 30, revenue: '$3,250' },
    { date: '2023-06-13', cardsCreated: 22, usersRegistered: 32, revenue: '$3,500' },
    { date: '2023-06-14', cardsCreated: 24, usersRegistered: 35, revenue: '$3,750' },
    { date: '2023-06-15', cardsCreated: 26, usersRegistered: 37, revenue: '$4,000' },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      {/* Top bar for mobile: toggles sidebar */}
      <div className="flex items-center justify-between bg-white px-4 py-3 shadow md:hidden">
        <h1 className="text-lg font-bold">Biton Card Admin</h1>
        <button
          className="text-gray-600 focus:outline-none"
          onClick={() => setSidebarOpen(!sidebarOpen)}
        >
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            {sidebarOpen ? (
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M6 18L18 6M6 6l12 12"
              />
            ) : (
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 6h16M4 12h16M4 18h16"
              />
            )}
          </svg>
        </button>
      </div>

      <div className="flex flex-1">
        {/* Sidebar */}
        <aside
          className={`${
            sidebarOpen ? 'block' : 'hidden'
          } md:block w-64 bg-white shadow-lg`}
        >
          <div className="px-6 py-4 border-b">
            <h2 className="text-xl font-bold">Admin Dashboard</h2>
          </div>
          <nav className="px-6 py-4">
            <ul className="space-y-2">
              <li>
                <a href="#" className="block px-3 py-2 rounded hover:bg-gray-100">
                  Dashboard
                </a>
              </li>
              <li>
                <a href="#" className="block px-3 py-2 rounded hover:bg-gray-100">
                  Users
                </a>
              </li>
              <li>
                <a href="#" className="block px-3 py-2 rounded hover:bg-gray-100">
                  Transactions
                </a>
              </li>
              <li>
                <a href="#" className="block px-3 py-2 rounded hover:bg-gray-100">
                  Reports
                </a>
              </li>
              <li>
                <a href="#" className="block px-3 py-2 rounded hover:bg-gray-100">
                  Settings
                </a>
              </li>
            </ul>
          </nav>
        </aside>

        {/* Main content */}
        <main className="flex-1 ">
          {/* Top Bar for desktop (search, etc.) */}
          <div className="hidden p-4 bg-white md:flex items-center justify-between mb-6">
            <h1 className="text-2xl font-bold">Admin Dashboard</h1>
            <div>
              <input
                type="text"
                placeholder="Search..."
                className="border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
<div className=' p-4 md:p-6'>

          {/* Stats cards */}
        
                        </div>
        </main>
      </div>
    </div>
  );
}
