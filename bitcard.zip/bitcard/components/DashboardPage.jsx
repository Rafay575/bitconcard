"use client";

import React, { useState } from "react";
import RecentTransactions from "./RecentTransactions";
import { useSelector } from "react-redux";
import CreateCard from "./CreateCard"; // Import the CreateCard component
import {CreditCard}  from "lucide-react"
import AddFund from "./AddFund";
export default function DashboardPage() {
  const user = useSelector((state) => state.auth.user);
  const [showModal, setShowModal] = useState(false);
  const [showAddFund, setAddFund] = useState(false);
  const firstName = user?.firstName || "John";
  const lastName = user?.lastName || "Doe";
  const balance = user?.balance ? parseFloat(user.balance).toFixed(2) : "0.00";

  return (
    <div className="bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Page Title */}
        <h1 className="mb-4 text-2xl font-semibold text-gray-800">
          Welcome back, {firstName} {lastName}
        </h1>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          {/* Left Side: Balance Card */}
          <div className="flex relative flex-col rounded-md bg-white p-6 pb-2 shadow">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-800">
                Available Balance
              </h2>
            </div>
            <div className="flex items-end justify-between">
              <p className="mt-2 text-3xl font-semibold text-gray-900">
                ${balance}
              </p>
              <p className="text-base text-end font-semibold">USD</p>
            </div>
            <div className="flex items-end justify-between">
              <p className="mt-3 text-sm text-gray-500">Confirming deposit: </p>
              <p className="text-yellow-400 font-semibold">$0.00</p>
            </div>
            <div className="mt-8 flex gap-2">
             
              <button   onClick={() => setAddFund(true)} className="!w-1/2 rounded bg-green-600 px-4 py-2 text-center font-semibold text-white hover:bg-green-700">
              <span className="mr-2">$</span> Add Money
              </button>
              <button
                onClick={() => setShowModal(true)}
                className="px-2 flex justify-center py-2 rounded-md border w-1/2 border-gray-300 text-gray-900 hover:bg-gray-100"
              >
               <CreditCard className="mr-2" /> Create Card
              </button>

            {showAddFund &&  <AddFund
                isOpen={showAddFund}
                closeModal={() => setAddFund(false)}
              />}
            {showModal &&  <CreateCard
                // show={showModal}
                onClose={() => setShowModal(false)}
              />}
            </div>
          </div>

          {/* Right Side: My Cards */}
          <div className="md:col-span-2 flex flex-col rounded-md bg-white p-6 shadow">
            <div className="flex items-center justify-between">
              <h2 className="mb-2 text-lg font-semibold text-gray-800">
                My Cards
              </h2>
              <span className="text-sm text-gray-500">2 Cards Active</span>
            </div>

            {/* Cards Grid */}
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {/* Example Card #1 */}
              <div className="rounded-md bg-gray-800 p-4 text-white">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-medium">My First Card</h3>
                  <span className="rounded bg-green-600 px-2 py-0.5 text-xs">
                    Active
                  </span>
                </div>
                <p className="text-sm">**** 1234</p>
                <p className="text-sm mt-4">Balance: $300.00</p>
                <p className="text-sm">Exp: 02/25</p>
              </div>

              {/* Example Card #2 */}
              <div className="rounded-md bg-gray-800 p-4 text-white">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-medium">Travel Card</h3>
                  <span className="rounded bg-red-600 px-2 py-0.5 text-xs">
                    Frozen
                  </span>
                </div>
                <p className="text-sm">**** 5678</p>
                <p className="text-sm mt-4">Balance: $250.00</p>
                <p className="text-sm">Exp: 06/24</p>
              </div>

              {/* Optionally, you can also place a CreateCard here as a placeholder */}
              {/* <CreateCard /> */}
            </div>
          </div>
        </div>

        <RecentTransactions />
      </div>
    </div>
  );
}
